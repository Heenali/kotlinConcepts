package com.example.demo

fun main()
{
    getSum(10,20)
}
fun getSum(a:Int, b:Int, c: Int =10)
{
    println(a+b+c)
}


