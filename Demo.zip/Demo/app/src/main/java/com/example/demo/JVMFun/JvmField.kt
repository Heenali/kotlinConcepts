package com.example.demo.JVMFun

class MyFieldClass {

    // Regular property
    var regularProperty: String = "Regular Property"

    // Property exposed as a public field using @JvmField
    @JvmField
    var fieldProperty: String = "Field Property"
}
