package com.example.demo.Functions

object myObject {

    var myObjectValue=10
    fun getObject()
    {
        println("HHHHHHHHHH")
    }

}
fun main()
{
    println(myObject.myObjectValue)
    myObject.getObject()
}